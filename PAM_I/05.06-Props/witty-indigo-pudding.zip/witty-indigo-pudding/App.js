import React from 'react';
import ListaDeSignos from './components/ListaDeSignos';

export default function App() {
  return (
    <ListaDeSignos />
  );
}
import { StyleSheet } from 'react-native';

const estilo = StyleSheet.create({
 lista: {
   padding: 10,
   marginBottom: 60,
 }
});

export default estilo;